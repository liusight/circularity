# Security Policy

For critical security issues, please send an e-mail to team@bower.io instead of filing issue here.
