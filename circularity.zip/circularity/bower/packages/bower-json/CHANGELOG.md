# 0.8.4

- Update deep-extend (security fix)

# 0.8.3

- Fix requires

# 0.8.2

- Drop dependency on meow (vendor ext-name)

# 0.8.1

- Revert strict name validations and allow @, spaces and slashes

# 0.8.0

- Update graceful-fs to 4.x
- Add name validations that reflect what's happening in registry

# 0.7.1

- Unpublished

# 0.7.0

- Add getIssues function to retrieve all errors and warnings
- Add readSync and findSync functions for synchronous read
